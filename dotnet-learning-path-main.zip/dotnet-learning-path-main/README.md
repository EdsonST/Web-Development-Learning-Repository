dotnet-learning-path

Repositório dedicado aos meus estudos de .NET e C#.
Aqui registro anotações, exercícios, projetos de prática e qualquer conteúdo que faça parte da minha jornada de aprendizado na plataforma .NET.

📚 Objetivos

Aprender os fundamentos da linguagem C#
Explorar os principais recursos do .NET
Criar pequenos projetos para fixação
Evoluir para conceitos avançados com o tempo

📁 Estrutura do Repositório

exercicios/ — exercícios práticos e desafios resolvidos
projetos/ — miniaplicações desenvolvidas durante os estudos

🛠️ Tecnologias

.NET SDK
C#
Visual Studio Code / Visual Studio

🚀 Progresso

O repositório é atualizado conforme avanço nos estudos.
Sugestões e contribuições são bem-vindas!
