﻿class Banda
{
    private long<Album> album = new List<Album>
    public string NomeDaBanda { get; set; }
}
