class tester
{
    static void Main()
    {
        /*/Course01
        var course = new Course01();
        //Teste CalculateAge
        course.CalculateAge(2000);
        //Teste Donations
        course.Donations(500.00m, true, 'P');
        //Teste ConversionMiles
        course.ConversionMiles(10);
        //Teste ConversionTime
        course.ConversionTime(250);
        //Teste AreaConverter
        course.AreaConverter(10.5, 20.3);
        //Teste AverageNote
        course.AverageNote(7.2, 8.3, 9.1);
        //Teste TruckForCargo
        course.TruckForCargo(18.75m);
        //Teste LivesControl 
        course.LivesControl(5);
        //Teste SalaryIncrease 
        course.SalaryIncrease(1500.00m, 10.0m);
        //Teste CircunferenceCalc 
        course.CircunferenceCalc(5.0m);
        */

        /* /Course02
        var course2 = new Course02();

        Teste BalanceAnalysis
        course2.BalanceAnalysis(-26.75m);

        //Teste ProductClassification 
        course2.ProductClassification();

        //Teste StuentAvaliation 
        course2.StuentAvaliation();

        //Teste CredentialValidation 
        course2.CredentialValidation();

        //Teste EtharialClassification 
        course2.EtharialClassification();

        //Teste Calculator 
        course2.Calculator();

        //Teste Greetings 
        course2.Greetings();

        //Teste CodeRewards
        course2.CodeRewards();

        //Teste BookClassification 
        course2.BookClassification();

        //Teste AutenticationAcess
        course2.AutenticationAcess();
        */

        /* /Course03
        var course3 = new Course03();

        //Teste Donations
        course3.Donations();

        //Teste  EventParticipants
        course3.EventParticipants();

        //Teste SecretPassword
        course3.SecretPassword();

        //Teste GameScore 
        course3.GameScore();

        //Teste SecretMessage 
        course3.SecretMessage();

        //Teste SorteioBeneficiente
        course3.SorteioBeneficiente();

        //Teste.ListaDeProdutos 
        course3.ListaDeProdutos();

        //Teste NotasFinais 
        course3.NotasFinais();

        //Teste Inventario
        course3.Inventario();

        //Teste TarefasDaSprint
        course3.TarefasDaSprint();
        */

        /* /Course04 
        var course4 = new Course04();

        /*
        //Teste PalavraChave
        course4.PalavraChave();

        //Teste ContadorDeCaracteres
        course4.ContadorDeCaracteres();
        
        //Teste SubstituirPalavra
        course4.SubstituirPalavra();

        //Teste DivisaoDeTexto 
        course4.DivisaoDeTexto();

        //Teste TransformandoEmMaiuscula 
        course4.TransformandoEmMaiusculas();

        //Teste RelatoriosDeEntregas 
        course4.RelatoriosDeEntregas();

        //Teste ValidadorDeCupons 
        course4.ValidadorDeCupons();

        //Teste ExtracaoDeTexto 
        course4.ExtracaoDeTexto();

        //Teste ExtracaoDeEspaco 
        course4.ExtracaoDeEspaco(); 

        //Teste ValidacaoDeData 
        course4.ValidacaoDeData();

        //Teste ValidacaoDeLinks 
        course4.ValidacaoDeLinks();
        */

        var course5 = new Course05();
    }
}
