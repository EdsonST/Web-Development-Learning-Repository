let listaGenerica = [];

let linguagensDeProgramacao = ["JavaScript", "C", "C++", "Kotlin", "Python"];

linguagensDeProgramacao.push("Java", "Ruby", "GoLang");

let listaDeNomes = ["Raul", "Juan", "Fernando"];
console.log(listaDeNomes[0]);
console.log(listaDeNomes[1]);
console.log(listaDeNomes[listaDeNomes.length - 1]);
