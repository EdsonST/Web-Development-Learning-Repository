function mensagemTela() {
  console.log("Olá, Mundo!");
}

function mensagemNominal(nome) {
  console.log(`Olá, ${nome}!`);
}

function dobroDoNumero(numero) {
  return numero * 2;
}

function mediaDosNumeros(n1, n2, n3) {
  return (n1 + n2 + n3) / 3;
}

function maiorDosNumeros(a, b) {
  return a > b ? a : b;
}

function multiplicacaoDoNumero(n) {
  return n * n;
}
